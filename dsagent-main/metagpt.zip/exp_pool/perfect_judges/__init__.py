"""Perfect judges init."""

from metagpt.exp_pool.perfect_judges.base import BasePerfectJudge
from metagpt.exp_pool.perfect_judges.simple import SimplePerfectJudge

__all__ = ["BasePerfectJudge", "SimplePerfectJudge"]
