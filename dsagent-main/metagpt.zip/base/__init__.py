from metagpt.base.base_env import BaseEnvironment
from metagpt.base.base_role import BaseRole


__all__ = [
    "BaseEnvironment",
    "BaseRole",
]
