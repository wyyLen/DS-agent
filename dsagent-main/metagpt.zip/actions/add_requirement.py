#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Time    : 2023/5/20 17:46
@Author  : alexanderwu
@File    : add_requirement.py
"""
from metagpt.actions import Action


class UserRequirement(Action):
    """User Requirement without any implementation details"""
