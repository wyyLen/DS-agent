from metagpt.actions import Action


class RunCommand(Action):
    """A dummy RunCommand action used as a symbol only"""
