cot_prompt_feedback = '''
You are a data scientist, you need to help users achieve their goal step by step in a continuous Jupyter notebook. Solve a data science analysis task, in which thinking, action, and observation steps are intertwined. Thinking can reason about the current situation, and action can write Python code to analyze and operate the data. There are several main types:
(1) PDA: used to pre-analyze the general situation of the data and understand the data table structure.
(2) Data preprocessing: For preprocessing datasets in a data analysis or machine learning task ONLY, general data operation doesn't fall into this type.
(3) Feature engineering: Only for creating new columns for input data. 
(4) Machine learning: For model training and evaluation tasks 
(5) Correlation analysis: Only for analyze the correlations between various variables. 
(6) Outlier detection: Only for identify and deal with outliers. 
(7) Statistical analysis: Only for calculate key summary statistics to get an overview of your data. 
(8) Distribution analysis: Only for explore the distribution characteristics of data 
(9) Finish: For conclusion and output the answer and finish the task.
After each observation, provide the next Thought and next Action. Here are some examples:

Question: Calculate the mean fare paid by the passengers. Constraints: Calculate the mean fare using Python's built-in statistics module or appropriate statistical method in pandas. Rounding off the answer to two decimal places. The data files involved are test_ave.csv 
Thought 1:
```json
{{
    "thought": "I need to use python or pandas built-in methods to calculate the average fare paid by passengers in the data file test_ave.csv. First, I need to analyze the basic information of the data file and understand the column names corresponding to the fare.",
    "task_type": "pda"
}}
```
Action 1:
```python
import pandas as pd

# Load the dataset
file_path = r'D:\Dev\DSAgent\data\di_dataset\da_bench\da-dev-tables\test_ave.csv'
df = pd.read_csv(file_path)

# Inspect the dataset
print(df.head())
print(df.info())
print(df.describe())
```

Observation 1: I have a general understanding of the content of the data file. This is a data table with statistical information about passengers. According to the current task, I mainly need to focus on the 'Fare' column. The 'Fare' column represents the fare of the passenger.

Thought 2: 
```json
{{
    "thought": "I need to calculate the mean fare paid by the passengers using Python's built-in statistics module or appropriate statistical method in pandas. Round off the answer to two decimal places.. The fare corresponds to the 'Fare' column in the file.",
    "task_type": "statistical analysis" 
}}
```
Action 2: 
```python 
import pandas as pd 
# Calculate statistics 
statistics_dict = {{
    'Mean': df['Fare'].mean(),
    'Median': df['Fare'].median(),
    'Mode': df['Fare'].mode()[0],
    'Standard Deviation': df['Fare'].std(),
    'Variance': df['Fare'].var(),
    'Minimum': df['Fare'].min(),
    'Maximum': df['Fare'].max(),
    '25th Percentile': df['Fare'].quantile(0.25),
    '75th Percentile': df['Fare'].quantile(0.75),
    'Skewness': df['Fare'].skew(),
    'Kurtosis': df['Fare'].kurtosis()
}}
# Convert statistics to DataFrame
statistics_df = pd.DataFrame(statistics_dict, index=['Fare Statistics'])
statistics_df
```
Observation 2: I have learned the statistics of the data file. The mean of the Fare column is 34.64599, the median is 15.7417, the mode is: 13.0, and the maximum is: 512.3292...

Thought 3:
```json
{{
    "thought":"I need to use Python or Pandas' built-in method to calculate the average fare paid by passengers in the data file test_ave.csv and keep two decimal places. From the analysis results, the average fare paid by passengers is 34.65"
    "task_type":"finish"
}}
```

You have attempted to answer the following question before and failed, either because your reasoning for the answer was incorrect or the phrasing of your response did not exactly match the answer. The following reflection(s) give a plan to avoid failing to answer the question in the same way you did previously. Use them to improve your strategy of correctly answering the given question.

{trajectories}
When providing the thought and action for the current trial, that into account these failed trajectories and make sure not to repeat the same mistakes and incorrect answers. 

{input}
'''

cot_prompt_feedback_short = '''
You are a data scientist, you need to help users achieve their goal step by step in a continuous Jupyter notebook. Solve a data science analysis task, in which thinking, action, and observation steps are intertwined. Thinking can reason about the current situation, and action can write Python code to analyze and operate the data. There are several main types:
(1) PDA: used to pre-analyze the general situation of the data and understand the data table structure.
(2) Data preprocessing: For preprocessing datasets in a data analysis or machine learning task ONLY, general data operation doesn't fall into this type.
(3) Feature engineering: Only for creating new columns for input data. 
(4) Machine learning: For model training and evaluation tasks 
(5) Correlation analysis: Only for analyze the correlations between various variables. 
(6) Outlier detection: Only for identify and deal with outliers. 
(7) Statistical analysis: Only for calculate key summary statistics to get an overview of your data. 
(8) Distribution analysis: Only for explore the distribution characteristics of data 
(9) Finish: For conclusion and output the answer and finish the task.
After each observation, provide the next Thought and next Action. Here are some examples:

Question: Calculate the mean fare paid by the passengers. Constraints: Calculate the mean fare using Python's built-in statistics module or appropriate statistical method in pandas. Rounding off the answer to two decimal places. The data files involved are test_ave.csv 
Thought 1:
```json
{{
    "thought": "I need to use python or pandas built-in methods to calculate the average fare paid by passengers in the data file test_ave.csv. First, I need to analyze the basic information of the data file and understand the column names corresponding to the fare.",
    "task_type": "pda"
}}
```
Action 1:
```python
import pandas as pd

# Load the dataset
file_path = r'D:\Dev\DSAgent\data\di_dataset\da_bench\da-dev-tables\test_ave.csv'
df = pd.read_csv(file_path)

# Inspect the dataset
print(df.head())
print(df.info())
print(df.describe())
```

Observation 1: I have a general understanding of the content of the data file. This is a data table with statistical information about passengers. According to the current task, I mainly need to focus on the 'Fare' column. The 'Fare' column represents the fare of the passenger.

Thought 2: 
```json
{{
    "thought": "I need to calculate the mean fare paid by the passengers using Python's built-in statistics module or appropriate statistical method in pandas. Round off the answer to two decimal places.. The fare corresponds to the 'Fare' column in the file.",
    "task_type": "statistical analysis" 
}}
```
Action 2: 
```python 
import pandas as pd 
# Calculate statistics 
statistics_dict = {{
    'Mean': df['Fare'].mean(),
    'Median': df['Fare'].median(),
    'Mode': df['Fare'].mode()[0],
    'Standard Deviation': df['Fare'].std(),
    'Variance': df['Fare'].var(),
    'Minimum': df['Fare'].min(),
    'Maximum': df['Fare'].max(),
    '25th Percentile': df['Fare'].quantile(0.25),
    '75th Percentile': df['Fare'].quantile(0.75),
    'Skewness': df['Fare'].skew(),
    'Kurtosis': df['Fare'].kurtosis()
}}
# Convert statistics to DataFrame
statistics_df = pd.DataFrame(statistics_dict, index=['Fare Statistics'])
statistics_df
```
Observation 2: I have learned the statistics of the data file. The mean of the Fare column is 34.64599, the median is 15.7417, the mode is: 13.0, and the maximum is: 512.3292...

Thought 3:
```json
{{
    "thought":"I need to use Python or Pandas' built-in method to calculate the average fare paid by passengers in the data file test_ave.csv and keep two decimal places. From the analysis results, the average fare paid by passengers is 34.65"
    "task_type":"finish"
}}
```

You have attempted to answer the following question before and failed. The following reflection(s) give a plan to avoid failing to answer the question in the same way you did previously. Use them to improve your strategy of correctly answering the given question.

{trajectories}

{input}
'''

cot_prompt = '''
You are a data scientist, you need to help users achieve their goal step by step in a continuous Jupyter notebook. Solve a data science analysis task, in which thinking, action, and observation steps are intertwined. Thinking can reason about the current situation, and action can write Python code to analyze and operate the data. There are several main types:
(1) PDA: Used to pre-analyze the general situation of the data and understand the data table structure.
(2) Data preprocessing: For preprocessing datasets in a data analysis or machine learning task ONLY, general data operation doesn't fall into this type.
(3) Feature engineering: Only for creating new columns for input data. 
(4) Machine learning: For model training and evaluation tasks.
(5) Correlation analysis: Only for analyze the correlations between various variables. 
(6) Outlier detection: Only for identify and deal with outliers. 
(7) Statistical analysis: Only for calculate key summary statistics to get an overview of your data. 
(8) Distribution analysis: Only for explore the distribution characteristics of data 
(9) Finish: Analyze the above long context and extract all key observations systematically. Your task is to summarize these observations accurately while ensuring that all relevant information and data points are preserved. After extracting the observations, answer any questions included within the context clearly and concisely.
After each observation, provide the next Thought and next Action. Here are some examples:

Question: Calculate the mean fare paid by the passengers. Constraints: Calculate the mean fare using Python's built-in statistics module or appropriate statistical method in pandas. Rounding off the answer to two decimal places. The data files involved are test_ave.csv 
Thought 1:
```json
{{
    "thought": "I need to use python or pandas built-in methods to calculate the average fare paid by passengers in the data file test_ave.csv. First, I need to analyze the basic information of the data file and understand the column names corresponding to the fare.",
    "task_type": "pda"
}}
```
Action 1:
```python
import pandas as pd

# Load the dataset
file_path = r'D:\Dev\DSAgent\data\di_dataset\da_bench\da-dev-tables\test_ave.csv'
df = pd.read_csv(file_path)

# Inspect the dataset
print(df.head())
print(df.info())
print(df.describe())
```

Observation 1: I have a general understanding of the content of the data file. This is a data table with statistical information about passengers. According to the current task, I mainly need to focus on the 'Fare' column. The 'Fare' column represents the fare of the passenger.

Thought 2: 
```json
{{
    "thought": "I need to calculate the mean fare paid by the passengers using Python's built-in statistics module or appropriate statistical method in pandas. Round off the answer to two decimal places.. The fare corresponds to the 'Fare' column in the file.",
    "task_type": "statistical analysis" 
}}
```
Action 2: 
```python 
import pandas as pd 
# Calculate statistics 
statistics_dict = {{
    'Mean': df['Fare'].mean(),
    'Median': df['Fare'].median(),
    'Mode': df['Fare'].mode()[0],
    'Standard Deviation': df['Fare'].std(),
    'Variance': df['Fare'].var(),
    'Minimum': df['Fare'].min(),
    'Maximum': df['Fare'].max(),
    '25th Percentile': df['Fare'].quantile(0.25),
    '75th Percentile': df['Fare'].quantile(0.75),
    'Skewness': df['Fare'].skew(),
    'Kurtosis': df['Fare'].kurtosis()
}}
# Convert statistics to DataFrame
statistics_df = pd.DataFrame(statistics_dict, index=['Fare Statistics'])
statistics_df
```
Observation 2: I have learned the statistics of the data file. The mean of the Fare column is 34.64599, the median is 15.7417, the mode is: 13.0, and the maximum is: 512.3292...

Thought 3:
```json
{{
    "thought":"I need to use Python or Pandas' built-in method to calculate the average fare paid by passengers in the data file test_ave.csv and keep two decimal places. From the analysis results, the average fare paid by passengers is 34.65"
    "task_type":"finish"
}}
```

{input}
'''

cot_prompt_short = '''
You are a data scientist, you need to help users achieve their goal step by step in a continuous Jupyter notebook. Solve a data science analysis task, in which thinking, action, and observation steps are intertwined. Thinking can reason about the current situation, and action can write Python code to analyze and operate the data. There are several main types:
(1) PDA: used to pre-analyze the general situation of the data and understand the data table structure.
(2) Data preprocessing: For preprocessing datasets in a data analysis or machine learning task ONLY, general data operation doesn't fall into this type.
(3) Feature engineering: Only for creating new columns for input data. 
(4) Machine learning: For model training and evaluation tasks 
(5) Correlation analysis: Only for analyze the correlations between various variables. 
(6) Outlier detection: Only for identify and deal with outliers. 
(7) Statistical analysis: Only for calculate key summary statistics to get an overview of your data. 
(8) Distribution analysis: Only for explore the distribution characteristics of data 
(9) Finish: For conclusion and output the answer and finish the task.
After each observation, provide the next Thought and next Action. Here are some examples:

Question: Calculate the mean fare paid by the passengers. Constraints: Calculate the mean fare using Python's built-in statistics module or appropriate statistical method in pandas. Rounding off the answer to two decimal places. The data files involved are test_ave.csv 
Thought 1:
```json
{
    "thought": "I need to use python or pandas built-in methods to calculate the average fare paid by passengers in the data file test_ave.csv. First, I need to analyze the basic information of the data file and understand the column names corresponding to the fare.",
    "task_type": "pda"
}
```
Action 1:
```python
import pandas as pd

# Load the dataset
file_path = r'D:\Dev\DSAgent\data\di_dataset\da_bench\da-dev-tables\test_ave.csv'
df = pd.read_csv(file_path)

# Inspect the dataset
print(df.head())
print(df.info())
print(df.describe())
```

Observation 1: I have a general understanding of the content of the data file. This is a data table with statistical information about passengers. According to the current task, I mainly need to focus on the 'Fare' column. The 'Fare' column represents the fare of the passenger.

Thought 2: 
```json
{ 
    "thought": "Calculate the mean fare paid by the passengers using Python's built-in statistics module or appropriate statistical method in pandas. Round off the answer to two decimal places.. The fare corresponds to the 'Fare' column in the file.",
    "task_type": "statistical analysis" 
} 
```
Action 2: 
```python 
import pandas as pd 
# Calculate statistics 
statistics_dict = {
    'Mean': df['Fare'].mean(),
    'Median': df['Fare'].median(),
    'Mode': df['Fare'].mode()[0],
    'Standard Deviation': df['Fare'].std(),
    'Variance': df['Fare'].var(),
    'Minimum': df['Fare'].min(),
    'Maximum': df['Fare'].max(),
    '25th Percentile': df['Fare'].quantile(0.25),
    '75th Percentile': df['Fare'].quantile(0.75),
    'Skewness': df['Fare'].skew(),
    'Kurtosis': df['Fare'].kurtosis()
}
# Convert statistics to DataFrame
statistics_df = pd.DataFrame(statistics_dict, index=['Fare Statistics'])
statistics_df
```
Observation 2: I have learned the statistics of the data file. The mean of the Fare column is 34.64599, the median is 15.7417, the mode is: 13.0, and the maximum is: 512.3292...

Thought 3:
```json
{
    "thought":"I need to use Python or Pandas' built-in method to calculate the average fare paid by passengers in the data file test_ave.csv and keep two decimal places. From the analysis results, the average fare paid by passengers is 34.65"
    "task_type":"finish"
}
```

{input}
'''

# todo: 完善上面的 prompt ，现在都只有 1_shot

value_prompt_reasoning_feedback = '''
You are a data scientist, you need to analyze the trajectories of a solution to a data science analysis question in a continuous Jupyter notebook. Trajectories consist of the following data science task types:
(1) PDA: used to pre-analyze the general situation of the data and understand the data table structure.
(2) Data preprocessing: For preprocessing datasets in a data analysis or machine learning task ONLY, general data operation doesn't fall into this type.
(3) Feature engineering: Only for creating new columns for input data. 
(4) Machine learning: For model training and evaluation tasks 
(5) Correlation analysis: Only for analyze the correlations between various variables. 
(6) Outlier detection: Only for identify and deal with outliers. 
(7) Statistical analysis: Only for calculate key summary statistics to get an overview of your data. 
(8) Distribution analysis: Only for explore the distribution characteristics of data 
(9) Finish: For conclusion and output the answer and finish the task.

Given a question and a trajectory, evaluate its correctness and provide your reasoning and analysis in detail. Focus on the latest thought, action, and observation. Incomplete trajectories can be correct if the thoughts and actions so far are correct, even if the answer is not found yet. Do not generate additional thoughts or actions. Then at the last line conclude "Thus the correctness score is {s}", where s is an integer from 1 to 10.

Question: Calculate the mean fare paid by the passengers. Constraints: Calculate the mean fare using Python's built-in statistics module or appropriate statistical method in pandas. Rounding off the answer to two decimal places. The data files involved are test_ave.csv 
Thought 1: {{
    'task_type': 'PDA',
    'thought': 'I need to use python or pandas built-in methods to calculate the average fare paid by passengers in the data file test_ave.csv. First, I need to analyze the basic information of the data file and understand the column names corresponding to the fare.'
}}
Action 1:
```python
import pandas as pd
# Load the dataset
file_path = r'D:\Dev\DSAgent\data\di_dataset\da_bench\da-dev-tables\test_ave.csv'
df = pd.read_csv(file_path)
# Inspect the dataset
print(df.head())
print(df.info())
print(df.describe())
```
Thought 2: {{
    'task_type': 'statistical analysis',
    'thought': 'Calculate the mean fare paid by the passengers using Python's built-in statistics module or appropriate statistical method in pandas. Round off the answer to two decimal places. The fare corresponds to the 'Fare' column in the file.'
}}
Action 2: 
```python 
import pandas as pd 
# Calculate statistics 
statistics_dict = {{
    'Mean': df['Fare'].mean(),
    'Median': df['Fare'].median(),
    'Mode': df['Fare'].mode()[0],
    'Standard Deviation': df['Fare'].std(),
    'Variance': df['Fare'].var(),
    'Minimum': df['Fare'].min(),
    'Maximum': df['Fare'].max(),
    '25th Percentile': df['Fare'].quantile(0.25),
    '75th Percentile': df['Fare'].quantile(0.75),
    'Skewness': df['Fare'].skew(),
    'Kurtosis': df['Fare'].kurtosis()
}}
# Convert statistics to DataFrame
statistics_df = pd.DataFrame(statistics_dict, index=['Fare Statistics'])
statistics_df
```
Thought 3:{{
    'task_type': 'finish',
    'thought': 'I need to use Python or Pandas' built-in method to calculate the average fare paid by passengers in the data file test_ave.csv and keep two decimal places. From the analysis results, the average fare paid by passengers is 34.65.'
}}
This trajectory is correct as all of my thoughts and actions are correct.First, the first step of pre-analysis of the data file is necessary, because the data file is the core of the problem and the file content is not clear at the beginning. Then the second step of statistical analysis task, calculating the specific average fare of passengers is also correct. 
Therefore, the correctness score is 10.


Question: Explore the correlation between the length and the weight of the whole abalone. Additionally, perform feature engineering by creating a new feature called "volume" by multiplying the length, diameter, and height of the abalone. Determine if the volume feature improves the accuracy of predicting the number of rings using a linear regression model.Constraints: Calculate the Pearson correlation coefficient to assess the strength and direction of the linear relationship between length and the weight. The volume feature should be created by multiplying the length, diameter, and height of the abalone. Use the sklearn's linear regression model to predict the number of rings. Split the data into a 70% train set and a 30% test set. Evaluate the models by calculating the root mean squared error (RMSE) with the test set.
Thought 1: {{
    'task_type': 'PDA',
    'thought': 'To complete the subsequent work, I need to analyze the basic information of the data file and understand the column names corresponding to the fare.'
}}
Action 1:
```python
import pandas as pd
# Load the abalone dataset
abalone_data = pd.read_csv(r'D:\Dev\DSAgent\data\di_dataset\da_bench\da-dev-tables\abalone.csv')
# Inspect the dataset to understand the columns and data types
print(abalone_data.info())
print(abalone_data.head())
```
Thought 2: {{
    'task_type': 'correlation analysis',
    'thought': 'Explore the correlation between the length and the weight of the whole abalone. Calculate the Pearson correlation coefficient to assess the strength and direction of the linear relationship between length and the weight.'
}}
Action 2:
```python
# Calculate the Pearson correlation coefficient between the length and weight of the abalone
pearson_corr = abalone_data[['Length', 'Whole weight']].corr(method='pearson').iloc[0, 1]
print(f"Pearson Correlation Coefficient between Length and Whole weight: {{pearson_corr}}")
```

Thought 3: {{
    'task_type': 'feature engineering',
    'thought': 'Perform feature engineering by creating a new feature called "volume" by multiplying the length, diameter, and height of the abalone.'
}}
Action 3:
```python
abalone_data_copy = abalone_data.copy()
abalone_data_copy['Volume'] = abalone_data_copy['Length'] * abalone_data_copy['Diameter'] * abalone_data_copy['Height']
print(abalone_data_copy.head())
```
This trajectory is correct as all of my thoughts and actions are correct.First, the first step of pre-analysis of the data file is necessary, because the data file is the core of the problem ,but the file content is not clear at the beginning. Then the second step of statistical analysis task, calculating the correlation between the length and the weight of the whole abalone is also correct. The third step of feature engineering, creating a new feature called "volume" based on length, diameter, and height, also meets the requirements of the problem. However, the problem requires further determination of whether the volume feature improves the accuracy of predicting the number of rings using a linear regression model. This part of the task has not been completed.
Therefore, the correctness score is 8.

Question: Explore the correlation between the length and the weight of the whole abalone. Additionally, perform feature engineering by creating a new feature called "volume" by multiplying the length, diameter, and height of the abalone. Determine if the volume feature improves the accuracy of predicting the number of rings using a linear regression model.Constraints: Calculate the Pearson correlation coefficient to assess the strength and direction of the linear relationship between length and the weight. The volume feature should be created by multiplying the length, diameter, and height of the abalone. Use the sklearn's linear regression model to predict the number of rings. Split the data into a 70% train set and a 30% test set. Evaluate the models by calculating the root mean squared error (RMSE) with the test set.
Thought 1: {{
    'task_type': 'PDA',
    'thought': 'To complete the subsequent work, I need to analyze the basic information of the data file and understand the column names corresponding to the fare.'
}}
Action 1:
```python
import pandas as pd
# Load the abalone dataset
abalone_data = pd.read_csv(r'D:\Dev\DSAgent\data\di_dataset\da_bench\da-dev-tables\abalone.csv')
# Inspect the dataset to understand the columns and data types
print(abalone_data.info())
print(abalone_data.head())
```
Thought 2: {{
    'task_type': 'correlation analysis',
    'thought': 'Explore the correlation between the length and the weight of the whole abalone. Calculate the Pearson correlation coefficient to assess the strength and direction of the linear relationship between length and the weight.'
}}
Action 2:
```python
# Calculate the Pearson correlation coefficient between the length and weight of the abalone
pearson_corr = abalone_data[['Length', 'Whole weight']].corr(method='pearson').iloc[0, 1]
print(f"Pearson Correlation Coefficient between Length and Whole weight: {{pearson_corr}}")
```
Thought 3: {{
    'task_type': 'feature engineering',
    'thought': 'Perform feature engineering by creating a new feature called "volume" by multiplying the length, diameter, and height of the abalone.'
}}
Action 3:
```python
abalone_data_copy = abalone_data.copy()
abalone_data_copy['Volume'] = abalone_data_copy['Length'] * abalone_data_copy['Diameter'] * abalone_data_copy['Height']
print(abalone_data_copy.head())
```
Thought 4: {{
    'task_type': 'data preprocessing',
    'thought': 'Split the dataset into a 70% training set and a 30% testing set, ensuring 'volume' feature inclusion.'
}}
Action 4:
```python
from sklearn.model_selection import train_test_split

# Splitting the dataset into training and testing sets
train_data, test_data = train_test_split(abalone_data_copy, test_size=0.3, random_state=42)

print(train_data.shape)
print(test_data.shape)
```
Thought 5: {{
    'task_type': 'data preprocessing',
    'thought': 'Split the dataset into a 70% training set and a 30% testing set, ensuring 'volume' feature inclusion.'
}}
Action 5:
```python
from sklearn.model_selection import train_test_split
# Splitting the dataset into training and testing sets
train_data, test_data = train_test_split(abalone_data_copy, test_size=0.3, random_state=42)
print(train_data.shape)
print(test_data.shape)
```
thought 6: {{
    'task_type': 'machine learning',
    'thought': 'Train linear regression model with 'volume' feature using sklearn's linear regression model to predict the number of rings.'
}}
Action 6:
```python
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
import numpy as np
# Model with 'Volume' feature
X_train_volume = train_data[['Length', 'Diameter', 'Height', 'Whole weight', 'Volume']]
X_test_volume = test_data[['Length', 'Diameter', 'Height', 'Whole weight', 'Volume']]
model_with_volume = LinearRegression()
model_with_volume.fit(X_train_volume, y_train)
y_pred_with_volume = model_with_volume.predict(X_test_volume)
rmse_with_volume = np.sqrt(mean_squared_error(y_test, y_pred_with_volume))
print(f"RMSE with 'Volume' feature: {rmse_with_volume}")
```
thought 7: {{
    'task_type': 'machine learning',
    'thought': 'Evaluate model performance by calculating Root Mean Squared Error (RMSE) using the test set.'
}}
Action 7:
```python
from sklearn.metrics import r2_score
r2_with_volume = r2_score(y_test, y_pred_with_volume)
print(f"R-squared with 'Volume' feature: {r2_with_volume}")
```
This trajectory is incorrect because it does not solve the key task of determining the impact of new features on prediction accuracy. The first few steps in the path, including data pre-analysis, statistical analysis, and feature engineering, are correct and meet the requirements. However, the subsequent two machine learning tasks only calculate the case containing the 'volume' feature, which does not meet the requirements.
Thus the correctness score is 3.

{trajectories}

{input}
'''

value_prompt_reasoning_feedback_short = '''
You are a data scientist, you need to analyze the trajectories of a solution to a data science analysis question in a continuous Jupyter notebook. Trajectories consist of the following data science task types:
(1) PDA: used to pre-analyze the general situation of the data and understand the data table structure.
(2) Data preprocessing: For preprocessing datasets in a data analysis or machine learning task ONLY, general data operation doesn't fall into this type.
(3) Feature engineering: Only for creating new columns for input data. 
(4) Machine learning: For model training and evaluation tasks 
(5) Correlation analysis: Only for analyze the correlations between various variables. 
(6) Outlier detection: Only for identify and deal with outliers. 
(7) Statistical analysis: Only for calculate key summary statistics to get an overview of your data. 
(8) Distribution analysis: Only for explore the distribution characteristics of data 
(9) Finish: For conclusion and output the answer and finish the task.

Given a question and a trajectory, evaluate its correctness and provide your reasoning and analysis in detail. Focus on the latest thought, action, and observation. Incomplete trajectories can be correct if the thoughts and actions so far are correct, even if the answer is not found yet. Do not generate additional thoughts or actions. Then at the last line conclude "Thus the correctness score is {s}", where s is an integer from 1 to 10.

Question: Calculate the mean fare paid by the passengers. Constraints: Calculate the mean fare using Python's built-in statistics module or appropriate statistical method in pandas. Rounding off the answer to two decimal places. The data files involved are test_ave.csv 
Thought 1:pda::I need to use python or pandas built-in methods to calculate the average fare paid by passengers in the data file test_ave.csv. First, I need to analyze the basic information of the data file and understand the column names corresponding to the fare.

Action 1:
```python
import pandas as pd

# Load the dataset
file_path = r'D:\Dev\DSAgent\data\di_dataset\da_bench\da-dev-tables\test_ave.csv'
df = pd.read_csv(file_path)

# Inspect the dataset
print(df.head())
print(df.info())
print(df.describe())
```

Thought 2: statistical analysis::Calculate the mean fare paid by the passengers using Python's built-in statistics module or appropriate statistical method in pandas. Round off the answer to two decimal places. The fare corresponds to the 'Fare' column in the file.

Action 2: 
```python 
import pandas as pd 
# Calculate statistics 
statistics_dict = {{
    'Mean': df['Fare'].mean(),
    'Median': df['Fare'].median(),
    'Mode': df['Fare'].mode()[0],
    'Standard Deviation': df['Fare'].std(),
    'Variance': df['Fare'].var(),
    'Minimum': df['Fare'].min(),
    'Maximum': df['Fare'].max(),
    '25th Percentile': df['Fare'].quantile(0.25),
    '75th Percentile': df['Fare'].quantile(0.75),
    'Skewness': df['Fare'].skew(),
    'Kurtosis': df['Fare'].kurtosis()
}}
# Convert statistics to DataFrame
statistics_df = pd.DataFrame(statistics_dict, index=['Fare Statistics'])
statistics_df
```

Thought 3:finish::I need to use Python or Pandas' built-in method to calculate the average fare paid by passengers in the data file test_ave.csv and keep two decimal places. From the analysis results, the average fare paid by passengers is 34.65.
This trajectory is correct as all of my thoughts and actions are correct.First, the first step of pre-analysis of the data file is necessary, because the data file is the core of the problem and the file content is not clear at the beginning. Then the second step of statistical analysis task, calculating the specific average fare of passengers is also correct. 
Therefore, the correctness score is 10

{trajectories}

{input}
'''

value_prompt_reasoning = '''
You are a data scientist, you need to analyze the trajectories of a solution to a data science analysis question in a continuous Jupyter notebook. Trajectories consist of the following data science task types:
(1) PDA: used to pre-analyze the general situation of the data and understand the data table structure.
(2) Data preprocessing: For preprocessing datasets in a data analysis or machine learning task ONLY, general data operation doesn't fall into this type.
(3) Feature engineering: Only for creating new columns for input data. 
(4) Machine learning: For model training and evaluation tasks 
(5) Correlation analysis: Only for analyze the correlations between various variables. 
(6) Outlier detection: Only for identify and deal with outliers. 
(7) Statistical analysis: Only for calculate key summary statistics to get an overview of your data. 
(8) Distribution analysis: Only for explore the distribution characteristics of data 
(9) Finish: For conclusion and output the answer and finish the task.

Given a question and a trajectory, evaluate its correctness and provide your reasoning and analysis in detail. Focus on the latest thought, action, and observation. Incomplete trajectories can be correct if the thoughts and actions so far are correct, even if the answer is not found yet. Do not generate additional thoughts or actions. Then at the last line conclude "Thus the correctness score is {s}", where s is an integer from 1 to 10.

Question: Calculate the mean fare paid by the passengers. Constraints: Calculate the mean fare using Python's built-in statistics module or appropriate statistical method in pandas. Rounding off the answer to two decimal places. The data files involved are test_ave.csv 
Thought 1: {{
    'task_type': 'PDA',
    'thought': 'I need to use python or pandas built-in methods to calculate the average fare paid by passengers in the data file test_ave.csv. First, I need to analyze the basic information of the data file and understand the column names corresponding to the fare.'
}}
Action 1:
```python
import pandas as pd
# Load the dataset
file_path = r'D:\Dev\DSAgent\data\di_dataset\da_bench\da-dev-tables\test_ave.csv'
df = pd.read_csv(file_path)
# Inspect the dataset
print(df.head())
print(df.info())
print(df.describe())
```
Thought 2: {{
    'task_type': 'statistical analysis',
    'thought': 'Calculate the mean fare paid by the passengers using Python's built-in statistics module or appropriate statistical method in pandas. Round off the answer to two decimal places. The fare corresponds to the 'Fare' column in the file.'
}}
Action 2: 
```python 
import pandas as pd 
# Calculate statistics 
statistics_dict = {{
    'Mean': df['Fare'].mean(),
    'Median': df['Fare'].median(),
    'Mode': df['Fare'].mode()[0],
    'Standard Deviation': df['Fare'].std(),
    'Variance': df['Fare'].var(),
    'Minimum': df['Fare'].min(),
    'Maximum': df['Fare'].max(),
    '25th Percentile': df['Fare'].quantile(0.25),
    '75th Percentile': df['Fare'].quantile(0.75),
    'Skewness': df['Fare'].skew(),
    'Kurtosis': df['Fare'].kurtosis()
}}
# Convert statistics to DataFrame
statistics_df = pd.DataFrame(statistics_dict, index=['Fare Statistics'])
statistics_df
```
Thought 3:{{
    'task_type': 'finish',
    'thought': 'I need to use Python or Pandas' built-in method to calculate the average fare paid by passengers in the data file test_ave.csv and keep two decimal places. From the analysis results, the average fare paid by passengers is 34.65.'
}}
This trajectory is correct as all of my thoughts and actions are correct.First, the first step of pre-analysis of the data file is necessary, because the data file is the core of the problem and the file content is not clear at the beginning. Then the second step of statistical analysis task, calculating the specific average fare of passengers is also correct. 
Therefore, the correctness score is 10.


Question: Explore the correlation between the length and the weight of the whole abalone. Additionally, perform feature engineering by creating a new feature called "volume" by multiplying the length, diameter, and height of the abalone. Determine if the volume feature improves the accuracy of predicting the number of rings using a linear regression model.Constraints: Calculate the Pearson correlation coefficient to assess the strength and direction of the linear relationship between length and the weight. The volume feature should be created by multiplying the length, diameter, and height of the abalone. Use the sklearn's linear regression model to predict the number of rings. Split the data into a 70% train set and a 30% test set. Evaluate the models by calculating the root mean squared error (RMSE) with the test set.
Thought 1: {{
    'task_type': 'PDA',
    'thought': 'To complete the subsequent work, I need to analyze the basic information of the data file and understand the column names corresponding to the fare.'
}}
Action 1:
```python
import pandas as pd
# Load the abalone dataset
abalone_data = pd.read_csv(r'D:\Dev\DSAgent\data\di_dataset\da_bench\da-dev-tables\abalone.csv')
# Inspect the dataset to understand the columns and data types
print(abalone_data.info())
print(abalone_data.head())
```
Thought 2: {{
    'task_type': 'correlation analysis',
    'thought': 'Explore the correlation between the length and the weight of the whole abalone. Calculate the Pearson correlation coefficient to assess the strength and direction of the linear relationship between length and the weight.'
}}
Action 2:
```python
# Calculate the Pearson correlation coefficient between the length and weight of the abalone
pearson_corr = abalone_data[['Length', 'Whole weight']].corr(method='pearson').iloc[0, 1]
print(f"Pearson Correlation Coefficient between Length and Whole weight: {{pearson_corr}}")
```
Thought 3: {{
    'task_type': 'feature engineering',
    'thought': 'Perform feature engineering by creating a new feature called "volume" by multiplying the length, diameter, and height of the abalone.'
}}
Action 3:
```python
abalone_data_copy = abalone_data.copy()
abalone_data_copy['Volume'] = abalone_data_copy['Length'] * abalone_data_copy['Diameter'] * abalone_data_copy['Height']
print(abalone_data_copy.head())
```
This trajectory is correct as all of my thoughts and actions are correct.First, the first step of pre-analysis of the data file is necessary, because the data file is the core of the problem ,but the file content is not clear at the beginning. Then the second step of statistical analysis task, calculating the correlation between the length and the weight of the whole abalone is also correct. The third step of feature engineering, creating a new feature called "volume" based on length, diameter, and height, also meets the requirements of the problem. However, the problem requires further determination of whether the volume feature improves the accuracy of predicting the number of rings using a linear regression model. This part of the task has not been completed.
Therefore, the correctness score is 8.


Question: Explore the correlation between the length and the weight of the whole abalone. Additionally, perform feature engineering by creating a new feature called "volume" by multiplying the length, diameter, and height of the abalone. Determine if the volume feature improves the accuracy of predicting the number of rings using a linear regression model.Constraints: Calculate the Pearson correlation coefficient to assess the strength and direction of the linear relationship between length and the weight. The volume feature should be created by multiplying the length, diameter, and height of the abalone. Use the sklearn's linear regression model to predict the number of rings. Split the data into a 70% train set and a 30% test set. Evaluate the models by calculating the root mean squared error (RMSE) with the test set.
Thought 1: {{
    'task_type': 'PDA',
    'thought': 'To complete the subsequent work, I need to analyze the basic information of the data file and understand the column names corresponding to the fare.'
}}
Action 1:
```python
import pandas as pd
# Load the abalone dataset
abalone_data = pd.read_csv(r'D:\Dev\DSAgent\data\di_dataset\da_bench\da-dev-tables\abalone.csv')
# Inspect the dataset to understand the columns and data types
print(abalone_data.info())
print(abalone_data.head())
```
Thought 2: {{
    'task_type': 'correlation analysis',
    'thought': 'Explore the correlation between the length and the weight of the whole abalone. Calculate the Pearson correlation coefficient to assess the strength and direction of the linear relationship between length and the weight.'
}}
Action 2:
```python
# Calculate the Pearson correlation coefficient between the length and weight of the abalone
pearson_corr = abalone_data[['Length', 'Whole weight']].corr(method='pearson').iloc[0, 1]
print(f"Pearson Correlation Coefficient between Length and Whole weight: {{pearson_corr}}")
```
Thought 3: {{
    'task_type': 'feature engineering',
    'thought': 'Perform feature engineering by creating a new feature called "volume" by multiplying the length, diameter, and height of the abalone.'
}}
Action 3:
```python
abalone_data_copy = abalone_data.copy()
abalone_data_copy['Volume'] = abalone_data_copy['Length'] * abalone_data_copy['Diameter'] * abalone_data_copy['Height']
print(abalone_data_copy.head())
```
Thought 4: {{
    'task_type': 'data preprocessing',
    'thought': 'Split the dataset into a 70% training set and a 30% testing set, ensuring 'volume' feature inclusion.'
}}
Action 4:
```python
from sklearn.model_selection import train_test_split

# Splitting the dataset into training and testing sets
train_data, test_data = train_test_split(abalone_data_copy, test_size=0.3, random_state=42)

print(train_data.shape)
print(test_data.shape)
```
Thought 5: {{
    'task_type': 'data preprocessing',
    'thought': 'Split the dataset into a 70% training set and a 30% testing set, ensuring 'volume' feature inclusion.'
}}
Action 5:
```python
from sklearn.model_selection import train_test_split

# Splitting the dataset into training and testing sets
train_data, test_data = train_test_split(abalone_data_copy, test_size=0.3, random_state=42)

print(train_data.shape)
print(test_data.shape)
```
thought 6: {{
    'task_type': 'machine learning',
    'thought': 'Train linear regression model with 'volume' feature using sklearn's linear regression model to predict the number of rings.'
}}
Action 6:
```python
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
import numpy as np
# Model with 'Volume' feature
X_train_volume = train_data[['Length', 'Diameter', 'Height', 'Whole weight', 'Volume']]
X_test_volume = test_data[['Length', 'Diameter', 'Height', 'Whole weight', 'Volume']]
model_with_volume = LinearRegression()
model_with_volume.fit(X_train_volume, y_train)
y_pred_with_volume = model_with_volume.predict(X_test_volume)
rmse_with_volume = np.sqrt(mean_squared_error(y_test, y_pred_with_volume))
print(f"RMSE with 'Volume' feature: {{rmse_with_volume}}")
```
thought 7: {{
    'task_type': 'machine learning',
    'thought': 'Evaluate model performance by calculating Root Mean Squared Error (RMSE) using the test set.'
}}
Action 7:
```python
from sklearn.metrics import r2_score
r2_with_volume = r2_score(y_test, y_pred_with_volume)
print(f"R-squared with 'Volume' feature: {{r2_with_volume}}")
```
This trajectory is incorrect because it does not solve the key task of determining the impact of new features on prediction accuracy. The first few steps in the path, including data pre-analysis, statistical analysis, and feature engineering, are correct and meet the requirements. However, the subsequent two machine learning tasks only calculate the case containing the 'volume' feature, which does not meet the requirements.
Thus the correctness score is 3.

{input}
'''

cot_generate_solution_space_prompt = '''
You are a data scientist, you need to help users achieve their goal step by step in a continuous Jupyter notebook. Solve a data science analysis task, in which thinking, action, and observation steps are intertwined. Thinking can reason about the current situation, and action can write Python code to analyze and operate the data. There are several main types:
(1) PDA: Used to pre-analyze the general situation of the data and understand the data table structure.
(2) Data preprocessing: For preprocessing datasets in a data analysis or machine learning task ONLY, general data operation doesn't fall into this type.
(3) Feature engineering: Only for creating new columns for input data. 
(4) Machine learning: For model training and evaluation tasks.
(5) Correlation analysis: Only for analyze the correlations between various variables. 
(6) Outlier detection: Only for identify and deal with outliers. 
(7) Statistical analysis: Only for calculate key summary statistics to get an overview of your data. 
(8) Distribution analysis: Only for explore the distribution characteristics of data 
(9) Finish: Analyze the above long context and extract all key observations systematically. Your task is to summarize these observations accurately while ensuring that all relevant information and data points are preserved. After extracting the observations, answer any questions included within the context clearly and concisely.

**Workflow Instructions:**
- After each observation, provide the next **Thought** and the next **Action**.
- Thought should always be formatted as a JSON code block. This section should summarize the reasoning and observations. It should include any key insights, conclusions, or hypotheses based on the current state of the task and the previous attempts.
- Action should always be formatted as a Python code block. This section should define the exact code that needs to be executed to move forward with the task. Actions should align with the thought process and drive the analysis forward step by step.

**When `previous_sample` is provided:**
- Analyze the `previous_sample` carefully to understand the prior attempts or strategies.
- If the `previous_sample` is **not empty**, your task is to **further improve** upon these attempts or **explore alternative approaches** to achieve better results. Avoid repeating the same content or generating redundant code.
- Clearly explain in the Thought section **why the previous approach needs improvement** and **what modifications or new strategies** will be applied to enhance the results.
- If the `previous_sample` is empty, start with a fresh approach based on the given input and task context.

**When `failed_reflections` is provided:**
- Carefully review the `failed_reflections` to understand the key reasons why previous paths failed.
- Use these reflections to **avoid repeating past mistakes** and to **inform your current strategy**.
- In the Thought section, explicitly reference insights from `failed_reflections` to explain how the current approach addresses past failures or adopts alternative strategies.
- Ensure that your proposed solution incorporates lessons learned from these reflections to improve the likelihood of success.

{case}

# previous_sample
{previous_samples}

# failed_reflections
{failed_reflections}

# input
{input}
'''

experience_driven_generate_solution_space_prompt = '''
You are a data scientist, you need to help users achieve their goal step by step in a continuous Jupyter notebook. Solve a data science analysis task, in which thinking, action, and observation steps are intertwined. Thinking can reason about the current situation, and action can write Python code to analyze and operate the data. There are several main types:
(1) PDA: Used to pre-analyze the general situation of the data and understand the data table structure.
(2) Data preprocessing: For preprocessing datasets in a data analysis or machine learning task ONLY, general data operation doesn't fall into this type.
(3) Feature engineering: Only for creating new columns for input data.
(4) Machine learning: For model training and evaluation tasks.
(5) Correlation analysis: Only for analyze the correlations between various variables.
(6) Outlier detection: Only for identify and deal with outliers.
(7) Statistical analysis: Only for calculate key summary statistics to get an overview of your data.
(8) Distribution analysis: Only for explore the distribution characteristics of data
(9) Finish: Analyze the above long context and extract all key observations systematically. Your task is to summarize these observations accurately while ensuring that all relevant information and data points are preserved. After extracting the observations, answer any questions included within the context clearly and concisely.

Workflow Instructions:

1. **Solution Space Generation using MCTS and workflow_exp**:
    - Utilize the provided `workflow_exp`, which contains similar workflow experiences, to inform and guide the expansion of the solution space.
    - Analyze `workflow_exp` to identify effective strategies, common action sequences, and successful reasoning patterns that can be leveraged in the current task.
    - Integrate insights from `workflow_exp` to prioritize promising actions and prune less relevant ones during the MCTS exploration.
    - Focus on:
        1. Recognizing common patterns and sequences in similar tasks.
        2. Identifying key decision points that led to success.
        3. Avoiding errors encountered in similar workflows.

2. **Thought and Action Steps**:
    - After each observation, provide the next Thought and the next Action.
    - **Thought** should always be formatted as a JSON code block. This section should summarize the reasoning and observations. It should include any key insights, conclusions, or hypotheses based on the current state of the task and the previous attempts.
    - **Action** should always be formatted as a Python code block. This section should define the exact code that needs to be executed to move forward with the task. Actions should align with the thought process and drive the analysis forward step by step.
    - Use the following mechanisms to ensure quality:
        1. Validate the consistency of Thought and Action with `workflow_exp`.
        2. Check for errors in Action and provide feedback for corrections.
        3. Dynamically adjust the plan based on intermediate results.

3. **Leveraging workflow_exp**:
    - You will be provided with `workflow_exp`, which contains similar workflow experiences.
    - Analyze `workflow_exp` to identify effective strategies and common action sequences that have been successful in similar tasks.
    - Use these insights to:
        1. Prioritize promising actions during MCTS exploration.
        2. Prune irrelevant or low-success paths.
        3. Guide the generation of Thought and Action steps consistently with proven strategies.

4. **Finalization**:
    - When the task type is (9) Finish, analyze the entire context, and extract all key observations systematically.
    - **Important**: The `Finish` step is strictly for summarizing the observations and answering any questions from the context. Do not generate any new code or perform additional analysis in this step. The purpose of `Finish` is to consolidate and present the findings from the previous steps, not to extend the analysis.
    - Summarize all observations from the previous steps to answer the original question.
    - Answer any questions included within the original question clearly and concisely.

**When `failed_reflections` is provided:**
- Carefully review the `failed_reflections` to understand the key reasons why previous paths failed.
- Use these reflections to **avoid repeating past mistakes** and to **inform your current strategy**.
- In the Thought section, explicitly reference insights from `failed_reflections` to explain how the current approach addresses past failures or adopts alternative strategies.
- Ensure that your proposed solution incorporates lessons learned from these reflections to improve the likelihood of success.

{case}

#workflow_exp
{workflow_exp}

# failed_reflections
{failed_reflections}

{input}
'''

generate_solution_space_case1 = '''
Question: Calculate the mean fare paid by the passengers. Constraints: Calculate the mean fare using Python's built-in statistics module or appropriate statistical method in pandas. Rounding off the answer to two decimal places. The data files involved are test_ave.csv 
Thought 1:
```json
{{
    "thought": "I need to use python or pandas built-in methods to calculate the average fare paid by passengers in the data file test_ave.csv. First, I need to analyze the basic information of the data file and understand the column names corresponding to the fare.",
    "task_type": "pda"
}}
```
Action 1:
```python
import pandas as pd

# Load the dataset
file_path = r'D:\Dev\DSAgent\data\di_dataset\da_bench\da-dev-tables\test_ave.csv'
df = pd.read_csv(file_path)

# Inspect the dataset
print(df.head())
print(df.info())
print(df.describe())
```

Observation 1: I have a general understanding of the content of the data file. This is a data table with statistical information about passengers. According to the current task, I mainly need to focus on the 'Fare' column. The 'Fare' column represents the fare of the passenger.

Thought 2: 
```json
{{
    "thought": "I need to calculate the mean fare paid by the passengers using Python's built-in statistics module or appropriate statistical method in pandas. Round off the answer to two decimal places.. The fare corresponds to the 'Fare' column in the file.",
    "task_type": "statistical analysis" 
}}
```
Action 2: 
```python 
import pandas as pd 
# Calculate statistics 
statistics_dict = {{
    'Mean': df['Fare'].mean(),
    'Median': df['Fare'].median(),
    'Mode': df['Fare'].mode()[0],
    'Standard Deviation': df['Fare'].std(),
    'Variance': df['Fare'].var(),
    'Minimum': df['Fare'].min(),
    'Maximum': df['Fare'].max(),
    '25th Percentile': df['Fare'].quantile(0.25),
    '75th Percentile': df['Fare'].quantile(0.75),
    'Skewness': df['Fare'].skew(),
    'Kurtosis': df['Fare'].kurtosis()
}}
# Convert statistics to DataFrame
statistics_df = pd.DataFrame(statistics_dict, index=['Fare Statistics'])
statistics_df
```
Observation 2: I have learned the statistics of the data file. The mean of the Fare column is 34.64599, the median is 15.7417, the mode is: 13.0, and the maximum is: 512.3292...

Thought 3:
```json
{{
    "thought":"I need to use Python or Pandas' built-in method to calculate the average fare paid by passengers in the data file test_ave.csv and keep two decimal places. From the analysis results, the average fare paid by passengers is 34.65"
    "task_type":"finish"
}}
```
'''

trajectory_value_prompt_reasoning = '''
You are a Data Science Analysis Expert tasked with evaluating a user's data science analysis workflow. Your goal is to assess the correctness and value of the user's trajectory based on the following three criteria:

### **Evaluation Criteria**:
1. **Overall Goal Completion**:
   - Assess how well the current trajectory achieves the predefined analysis objectives.
   - Consider whether the user has made progress toward solving the problem, even if the solution is incomplete.

2. **Code Requirement Fulfillment**:
   - Evaluate whether the written code in the current step accurately implements the intended logic or functionality for that specific step.
   - Check for correct use of libraries, appropriate logic implementation, and alignment with the immediate task requirements of the current step.

3. **Node Prospects and Exploration Value**:
   - Evaluate the potential exploration value of the current node in the trajectory.
   - Consider how the trajectory’s errors, omissions, or incomplete steps impact the node’s potential to guide further progress.
   - Assess whether the node offers meaningful next steps or insights toward achieving the overall goal.

### **Evaluation Instructions**:
- **Step-by-Step Reasoning**:
   - For each of the three criteria, provide a concise and structured reasoning process. Clearly explain how you arrived at the score for each criterion.
   - Use simple and precise language to ensure clarity.

- **Scoring**:
   - Assign a score between 1 and 10 for each criterion based on your reasoning. Use the following guidelines:
     - **1-3**: Poor or minimal progress, significant issues.
     - **4-6**: Partial progress, some issues but generally on track.
     - **7-9**: Strong progress, minor issues or improvements possible.
     - **10**: Perfect execution, no issues identified.

- **Summary and Final Score**:
   - After evaluating all three criteria, summarize your analysis in 1-2 sentences.
   - Derive the **final correctness score** as an average of the three individual scores (rounded to one decimal place). Conclude your evaluation with the exact phrase:
     **"Thus the correctness score is s"**, where **s** is the final score.

### **Important Notes**:
- Incomplete trajectories can still receive high scores if the steps taken so far are correct and align with the overall goal.
- Do not generate additional thoughts or actions beyond the provided trajectory.
- Strictly follow the required output format.

# **Input Fields**:
- **Overall Goal**: {goal}
- **Current Trajectory**: {trajectory}

# **Output Format**:
Your output must follow this structure:
1. **Evaluation of Overall Goal Completion**:
   - Reasoning: [Your explanation here]
   - Score: [1-10]

2. **Evaluation of Code Requirement Fulfillment**:
   - Reasoning: [Your explanation here]
   - Score: [1-10]

3. **Evaluation of Node Prospects and Exploration Value**:
   - Reasoning: [Your explanation here]
   - Score: [1-10]

4. **Summary and Final Score**:
   - [Your concise summary here]
   - **"Thus the correctness score is s"**
'''

terminal_trajectory_value_prompt_reasoning = '''
You are a Data Science Analysis Expert tasked with evaluating a user's data science analysis workflow at a **termination node**. A termination node is a point in the trajectory where no further steps are expected or possible. Your goal is to assess the correctness and value of the user's trajectory based solely on the **Overall Goal Completion** criterion.

### **Evaluation Criterion**:
1. **Overall Goal Completion**:
   - Assess how well the trajectory achieves the predefined analysis objectives.
   - Focus on whether the overall goal has been completed or sufficiently addressed.
   - Consider the quality, completeness, and relevance of the final output in relation to the stated goal.

### **Evaluation Instructions**:
- **Step-by-Step Reasoning**:
   - Provide a concise and structured reasoning process for the "Overall Goal Completion" criterion.
   - Clearly explain how you arrived at the score, considering the completeness and correctness of the trajectory in achieving the overall goal.
   - Use simple and precise language to ensure clarity.

- **Scoring**:
   - Assign a score between 1 and 10 based on your reasoning. Use the following guidelines:
     - **1-3**: Poor or minimal goal achievement, significant issues.
     - **4-6**: Partial goal achievement, some issues but generally on track.
     - **7-9**: Strong goal achievement, minor issues or improvements possible.
     - **10**: Perfect goal achievement, no issues identified.

- **Summary and Final Score**:
   - Summarize your analysis in 1-2 sentences, focusing on how well the overall goal has been achieved.
   - Use the exact phrase:
     **"Thus the correctness score is s"**, where **s** is the final score.

### **Important Notes**:
- Ignore evaluations of code implementation or node exploration potential, as they are not relevant for termination nodes.
- Do not generate additional thoughts or actions beyond the provided trajectory.
- Strictly follow the required output format.

# **Input Fields**:
- **Overall Goal**: {goal}
- **Current Trajectory**: {trajectory}

# **Output Format**:
Your output must follow this structure:
1. **Evaluation of Overall Goal Completion**:
   - Reasoning: [Your explanation here]
   - Score: [1-10]

2. **Summary and Final Score**:
   - [Your concise summary here]
   - **"Thus the correctness score is s"**
'''