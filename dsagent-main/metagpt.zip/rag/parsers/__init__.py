from metagpt.rag.parsers.omniparse import OmniParse

__all__ = ["OmniParse"]
